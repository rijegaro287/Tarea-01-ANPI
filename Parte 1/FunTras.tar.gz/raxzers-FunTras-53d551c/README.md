# pkg-example


**Content:**


1. Instalacion


## 1. Instalacion

Para obtener el tarball de este paquete se ecribe esta direccion en el navegador y se descarga automaticxamente el achivo :

     "https://github.com/raxzers/FunTras/tarball/master/"

Para instalar el paquete se ubica este en el directorio donde se encuentra la carpeta del usuario dependiendo del sistema operativo y se ejecuta el comando 

      "pkg install funTras.tar.gz"

Para cargar el paquete se ejecuta el comando 

      "pkg load FunTras"


